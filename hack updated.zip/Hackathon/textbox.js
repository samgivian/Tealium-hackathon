console.log('hello');

function savedata() {
  var text = $('#exampleFormControlTextarea1').val();
  console.log(text);
 
}